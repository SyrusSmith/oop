<?php

class Sediento extends Estado
{
    public function comer()
    {
        echo "Nada<br>";
    }

    public function tomar()
    {
        echo "?";
    }

    public function mimos()
    {
        echo "Nada<br>";
    }
}