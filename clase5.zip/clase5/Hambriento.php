<?php

class Hambriento extends Estado
{
    public function comer()
    {
        echo "?";
    }

    public function tomar()
    {
        echo "Nada<br>";
    }

    public function mimos()
    {
        echo "Nada<br>";
    }
}