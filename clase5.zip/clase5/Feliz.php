<?php

class Feliz extends Estado
{
    public function comer()
    {
        echo "Nada<br>";
    }

    public function tomar()
    {
        echo "5 beeps<br>";
    }

    public function mimos()
    {
        echo "nada<br>";
    }
}