<?php

class Triste extends Estado
{
    public function comer()
    {
        echo "2 beeps, vomita<br>";
    }

    public function tomar()
    {
        echo "3 beeps, titila<br>";
    }

    public function mimos()
    {
        echo "?";
    }
}